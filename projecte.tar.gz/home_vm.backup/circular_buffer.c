#include "circular_buffer.h"
#include "sched.h"

CircularBuffer keybuff;

void init_cbuf(CircularBuffer *cbuf)
{
  cbuf->write = 0;
  cbuf->read = 0;
}

int read_cbuf(CircularBuffer *cbuf, key *k)
{
  if (cbuf->read == cbuf->write)
  {
     // buffer is empty
     return 0;
  }

  *k = cbuf->buffer[cbuf->read];
  cbuf->read= (cbuf->read+ 1) % CBUFF_SIZE;
  return 1;
}

int write_cbuf(CircularBuffer *cbuf, key k)
{
  if ((cbuf->write + 1) % CBUFF_SIZE == cbuf->read)
  {
     // buffer is full, avoid overflow
     return 0;
  }

  cbuf->buffer[cbuf->write] = k;
  cbuf->write= (cbuf->write+ 1) % CBUFF_SIZE;
  return 1;
}
