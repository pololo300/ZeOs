#ifndef __CIRCULAR_BUFFER__ 
#define __CIRCULAR_BUFFER__ 

#define CBUFF_SIZE 512

typedef char key;
typedef struct {
    key buffer[CBUFF_SIZE];
    int write; // index to write to
    int read; // index to read from
} CircularBuffer;

void init_cbuf(CircularBuffer *cbuf);
int read_cbuf(CircularBuffer *cbuf, key *k);

int write_cbuf(CircularBuffer *cbuf, key k);

extern CircularBuffer keybuff;
#endif 
