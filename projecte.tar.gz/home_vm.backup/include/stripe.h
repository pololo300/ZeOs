#ifndef __STRIPE__
#define __STRIPE__

typedef struct {
  int x;  //number of rows
  int y;  //number of columns
  char* content; //pointer to sprite content matrix(X,Y)
} Sprite;

#endif // !__STRIPE__
