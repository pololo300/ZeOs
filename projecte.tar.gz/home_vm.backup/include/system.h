/*
 * system.h - Capçalera del mòdul principal del sistema operatiu
 */

#ifndef __SYSTEM_H__
#define __SYSTEM_H__

#include "circular_buffer.h"
#include "interrupt.h"
#include <types.h>


extern TSS         tss;
extern Descriptor* gdt;
extern CircularBuffer keybuff;

#endif  /* __SYSTEM_H__ */
