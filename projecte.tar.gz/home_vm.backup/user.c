#include "io.h"
#include <stripe.h>
#include <libc.h>

char buff[24];

int pid;

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */


  SetColor(F_BLACK,B_CYAN);
  gotoXY(10, 10);
  write(1,"HOLAAA", 7);

  SetColor(F_BLACK,B_GREEN);
  Sprite sp;
  sp.x = 3;
  sp.y = 3;
  sp.content = "OOOOOOOOO";//{'a','b','c','d'};
  
  spritePut(20, 20, &sp);

  while(1)
  {
    ;
  }
}
